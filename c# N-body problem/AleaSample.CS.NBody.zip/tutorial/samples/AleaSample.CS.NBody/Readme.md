This example solves the n-body problem in parallel and visualized the particles with OpenGL.
