## Steps to build and run samples
1. Double click `paket_setup.bat` to restore/install packages via [Paket](https://fsprojects.github.io/Paket/index.html)
2. Open sample solution with Visual Studio 2015
3. Select `Release` mode, then build
4. For application sample, press Ctrl-F5 to run it, for nunit tests, use test runner to run it
